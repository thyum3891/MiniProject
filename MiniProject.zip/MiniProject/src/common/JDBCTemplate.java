package common;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class JDBCTemplate {
	// 공통부 코드를 작성
	// JDBC 관련 Drivr 로드, Connection 관리

	
	public static final int ERROR_CODE_USER_DUPLE = 100; // 유저 ID 중복인 경우
	
//	public static String driverClass = "oracle.jdbc.OracleDriver";
	public static String url 		 = "jdbc:oracle:thin:@127.0.0.1:1521:xe";
	public static String user 		 = "MINI";
	public static String password 	 = "MINI";

//	static {
//		try {
//			Class.forName(driverClass);
//		} catch (ClassNotFoundException e) {
//			e.printStackTrace();
//		}
//	}
	
	
	public static Connection getConnection() {
		Connection conn = null;
		try {
			//2. Connection객체생성 url, user, password
			conn = DriverManager.getConnection(url, user, password);
			//2.1 자동커밋 false설정
			conn.setAutoCommit(false);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return conn;
		
	}
	
	public static void close(Connection conn) {
		try {
			if(conn != null)
				conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public static void commit(Connection conn) {
		try {
			if(conn != null)
				conn.commit();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public static void rollback(Connection conn) {
		try {
			if(conn != null)
				conn.rollback();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
}
