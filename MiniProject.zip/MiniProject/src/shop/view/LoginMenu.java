package shop.view;

import java.util.Scanner;

import shop.model.vo.Member;
import shop.user.controller.UserController;

public class LoginMenu {

	private UserController memberController = new UserController();
	private AdminMenu adminMenu = new AdminMenu();
	private Scanner sc = new Scanner(System.in);
private UserMenu userMenu = new UserMenu();
	
	/* =====================================================================================
	 *										로그인 메뉴
	 * ===================================================================================== 
	 */	
	public void startMenu() {
		String menu = "=======쇼핑몰======\n"
				+"1. 로그인\n"
				+"2. 회원가입\n"
				+"0. 프로그램 종료\n"
				+"================\n"
				+"선택 : ";
		
		while(true) {
			System.out.print(menu);
			int choice = sc.nextInt();
			sc.nextLine();
			
			//객체 및 변수 초기화
			Member member = null;
			int result = 0;
			String msg = null;
			
			switch (choice) {
			case 1:
				//로그인
				member = inputLoginMember(); //id,pwd 입력
				result = memberController.loginMember(member);
				switch (result) {
				case 0:
					System.out.println("관리자 로그인 성공");
					adminMenu.menu(member.getId());; //Admin 페이지로~
					break;
				case 1:
					System.out.println("회원 로그인 성공");
					userMenu.Menu(member.getId());
					break;
				case 2:
					System.out.println("패스워드 불일치");
					break;
				default:
					System.out.println("아이디 없음");
				}
				
				break;
			case 2:
				//회원가입
				member = inputMember(); //회원정보 입력
				System.out.println("===신규회원===");
				System.out.println(member); //입력한 회원가입 정보 출력
				result = memberController.insertMember(member);
				msg = result > 0 ? "회원가입 성공" : "회원가입 실패";
				System.out.println(msg);
				break;
			case 0:
				//프로그램 종료
				System.out.print("프로그램 종료 하시겠습니까?(y/n) : ");
				if(sc.nextLine().toLowerCase().charAt(0) == 'y')
					return; //종료
				break;
			default:
				System.out.println("잘못 입력하셨습니다.");
			}
		}
	}

	// 로그인을 위한 id,pwd 입력
	private Member inputLoginMember() {
		System.out.println("★로그인★");
		Member member = new Member();
		System.out.print("아이디 : ");
		member.setId(sc.nextLine());
		System.out.print("패스워드 : ");
		member.setPwd(sc.nextLine());
		return member;
	}

	// 회원가입을 위한 회원정보 입력
	private Member inputMember() {
		System.out.println("새로운 회원정보를 입력하세요.");
		Member member = new Member();
		System.out.print("아이디 : ");
		member.setId(sc.nextLine());
		System.out.print("패스워드 : ");
		member.setPwd(sc.nextLine());
		System.out.print("이름 : ");
		member.setName(sc.nextLine());
		System.out.print("주소 : ");
		member.setAddress(sc.nextLine());
		System.out.print("이메일 : ");
		member.setEmail(sc.nextLine());
		System.out.print("전화번호(-제외) : ");
		member.setPhone(sc.nextLine());
//		sc.nextLine();//버퍼에 남은 개행문자 날리기용 (next계열 - nextLine)
		return member;
	}
}
