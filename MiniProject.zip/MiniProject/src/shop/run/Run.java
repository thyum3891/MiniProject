package shop.run;



//import shop.admin.controller.AdminController;
//import shop.view.AdminMenu;
import shop.view.LoginMenu;
//import shop.view.UserMenu;

public class Run {

	public static void main(String[] args) {
		
		
//		AdminController adminController = new AdminController();
//		List<Product> list = new ProductDao().selectCategory("음료수 아닌거");
//		new ProductDao().deleteAll();
		
//		List<Product> list = new ProductDao().selectAll();
//		
//		
//		
//		
//		for(int i = 0; i<list.size();i++) {
//			if(list.get(i)==null) {
//				continue;
//			}
//			System.out.println(list.get(i).toString());
//		}
		
//		AdminMenu am = new AdminMenu();
//		UserMenu um = new UserMenu();
//
//		um.Menu("test11");
		
//		am.menu("test11");
	
		LoginMenu loginMenu = new LoginMenu();
		
		loginMenu.startMenu();
		
//		for(int i = 0;i<100000;i++) {
//		
//		adminController.addPro(("testProName"+i), ("testProDesc"+i), 1000, 10, "1", "test");
//		
//		}
	}

}
