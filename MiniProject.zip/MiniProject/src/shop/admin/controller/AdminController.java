package shop.admin.controller;

import java.util.List;

import shop.model.dao.ProductDao;
import shop.model.vo.Product;

public class AdminController {

	ProductDao productDao = new ProductDao();
	Product product = new Product();

//				1. 상품조회 => 조회할 카테고리 선택 => 카테고리 별 상품 조회 @  /

	public List<Product> productInquiry(int inputPage, int inputPageSize) { // 상품명, 상품 가격, 재고, 판매여부

		return productDao.selectAllPage(inputPage, inputPageSize);
//		return productDao.selectAll();
	}

	public List<String> selectCategory(int inputPage, int inputPageSize) {
		return productDao.selectCategoryPage(inputPage, inputPageSize);
//		return productDao.category();
	}
	public List<String> selectCategory() {
//		return productDao.selectCategoryPage(inputPage, inputPageSize);
		return productDao.category();
	}

	public List<Product> selectCategoryPro(String categoryName, int inputPage, int inputPageSize) {

		return productDao.selectCategoryProPage(categoryName, inputPage, inputPageSize);
//		return productDao.selectCategoryPro();
	}

	public Product selectProduct(int selectProNo) {

		return productDao.selectOne(selectProNo);

	}
	
	

	public int updateProduct(Product product, int selectProductNo) {
		return productDao.updateProduct(product, selectProductNo);
	}

	public int deleteProduct(int selectProNo) {
		return productDao.deleteProduct(selectProNo);
	}

//				상품등록 => 상품데이터 추가

	public int addPro(String proName, String proDesc, int proPrice, int proStock, String proState, String proCategory) {

		return productDao.insertProduct(proName, proDesc, proPrice, proStock, proState, proCategory);
		
	}

//				상품제거 => 상품데이터 삭제

	public int deleteCategory(String category) {

		return productDao.deleteCategory(category);
		
	}

//				5. 주문현황 => 주문완료된 회원의 데이터 받아서 조회 => 배송현황(배송준비,배송중,배송완료,주문취소(재고없음/기타))

//				6. 반품현황 => 반품처리 or 반려

}
