package shop.model.dao;

import static common.JDBCTemplate.commit;
import static common.JDBCTemplate.rollback;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import shop.model.vo.Review;

public class ReviewDao {

	Connection conn = null;

	public ReviewDao(Connection conn) {

		this.conn = conn;

	}

	public List<Review> selectAllPro(int proNo) {
		List<Review> list = new ArrayList<Review>();
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {

			String sql = "SELECT * FROM REVIEW WHERE pro_no = ?";

			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, proNo);
			rs = pstmt.executeQuery();

			while (rs.next()) {

				Review review = new Review();

				review.setReviewNo(rs.getInt(1));
				review.setId(rs.getString(2));
				review.setProNo(rs.getInt(3));
				review.setOrderNo(rs.getInt(4));
				review.setProStar(rs.getInt(5));
				review.setProReview(rs.getString(6));
				review.setReviewDate(rs.getDate(7));

				list.add(review);
			}

			return list;

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (pstmt != null) {
					pstmt.close();
				}
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}

		return null;

	}

	public List<Review> selectAllMeberId(int memberId) {
		List<Review> list = new ArrayList<Review>();
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {

			String sql = "SELECT * FROM REVIEW WHERE id = ?";

			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, memberId);
			rs = pstmt.executeQuery();

			while (rs.next()) {

				Review review = new Review();

				review.setReviewNo(rs.getInt(1));
				review.setId(rs.getString(2));
				review.setProNo(rs.getInt(3));
				review.setOrderNo(rs.getInt(4));
				review.setProStar(rs.getInt(5));
				review.setProReview(rs.getString(6));
				review.setReviewDate(rs.getDate(7));

				list.add(review);
			}

			return list;

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (pstmt != null) {
					pstmt.close();
				}
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}

		return null;

	}

	public List<Review> selectAllOrder(int orderNo) {
		List<Review> list = new ArrayList<Review>();
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {

			String sql = "SELECT * FROM REVIEW WHERE ORDER_NO = ?";

			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, orderNo);
			rs = pstmt.executeQuery();

			while (rs.next()) {

				Review review = new Review();

				review.setReviewNo(rs.getInt(1));
				review.setId(rs.getString(2));
				review.setProNo(rs.getInt(3));
				review.setOrderNo(rs.getInt(4));
				review.setProStar(rs.getInt(5));
				review.setProReview(rs.getString(6));
				review.setReviewDate(rs.getDate(7));

				list.add(review);
			}

			return list;

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (pstmt != null) {
					pstmt.close();
				}
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}

		return null;

	}

	public int insertReview(Review review) {

		int result = 0;

		PreparedStatement pstmt = null;

		try {
			String sql = "INSERT INTO REVIEW VALUES SEQ_REVIEW_NO.NEXTVAL,?,?,?,?,?,SYSDATE";

			pstmt = conn.prepareStatement(sql);

			pstmt.setString(1, review.getId());
			pstmt.setInt(2, review.getProNo());
			pstmt.setInt(3, review.getProStar());
			pstmt.setInt(4, review.getOrderNo());
			pstmt.setString(5, review.getProReview());

			result = pstmt.executeUpdate();

			if (result > 0) {
				commit(conn);
			} else {
				rollback(conn);
			}

		} catch (Exception e) {
			e.printStackTrace();

		} finally {
			try {
				if (pstmt != null) {
					pstmt.close();
				}
			} catch (SQLException e) {
				//
				e.printStackTrace();
			}
		}

		return result;
	}

}
