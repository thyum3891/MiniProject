package shop.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import shop.model.vo.Member;

public class MemberDao {
	
	private Connection conn = null;

	public MemberDao(Connection conn) {
		this.conn = conn;
	}
	
	//로그인	
	public int loginMember(Member member) {
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			String sql = "SELECT PWD,ADMIN FROM MEMBER WHERE ID = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, member.getId());
			rs = pstmt.executeQuery();
			if(rs.next()) {
				if(rs.getString("PWD").contentEquals(member.getPwd())) { //로그인 성공
					if(rs.getString("ADMIN").equals("Y")) {
						return 0; //관리자 로그인
					} else {
						return 1; //회원 로그인
					}
				}
				else { //패스워드 불일치
					return 2; //패스워드 불일치
				}
			}
			return -1; //아이디 불일치
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				pstmt.close();
			} catch (SQLException e2) {
				e2.printStackTrace();
			}
		}
		return -2; //db오류
	}
	//패스워드 불일치 2
	//회원 로그인 1
	//관리자 로그인 0
	//아이디 불일치 -1
	//db오류 -2
	
	//회원가입
	public int insertMember(Member member) {
		
		PreparedStatement pstmt = null;
		
		try {
			String sql = "INSERT INTO MEMBER VALUES(?,?,?,?,?,?,SYSDATE,0,'N')";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, member.getId());
			pstmt.setString(2, member.getPwd());
			pstmt.setString(3, member.getName());
			pstmt.setString(4, member.getAddress());
			pstmt.setString(5, member.getEmail());
			pstmt.setString(6, member.getPhone());
			
			int result = pstmt.executeUpdate();
			
			return result;
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
			} catch (SQLException e2) {
				e2.printStackTrace();
			}
		}
		return -1;
	}

	
}
