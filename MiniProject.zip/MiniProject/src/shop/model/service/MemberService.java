package shop.model.service;

import java.sql.Connection;

import shop.model.dao.MemberDao;
import shop.model.vo.Member;

import static common.JDBCTemplate.*;

public class MemberService {
	
	private MemberDao memberDao = null;
	private Connection conn = null;
	
	public MemberService() {
		init();
	}
	
	public void init() { //명시적 초기화
		
		if(conn != null) { //혹시모를 conn 초기화
			close(conn); //템플릿
		}
		
		conn = getConnection(); //템플릿
		memberDao = new MemberDao(conn);
	}
	
	public int loginMember(Member member) {
		return memberDao.loginMember(member);
	}
	
	public int insertMember(Member member) {
		int result = memberDao.insertMember(member);
		if(result >0) {
			commit(conn);
		} else {
			rollback(conn);
		}
		return result;
	}

}
