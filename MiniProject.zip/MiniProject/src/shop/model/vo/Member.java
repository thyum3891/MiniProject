package shop.model.vo;

import java.sql.Date;

public class Member {
	private String id;
	private String pwd;
	private String name;
	private String address;
	private String email;
	private String phone;
	private Date   join_date;
	private int	   point;
	private String admin;
	
	public Member() {}

	public Member(String id, String pwd, String name, String address, String email, String phone, Date join_date,
			int point, String admin) {
		super();
		this.id = id;
		this.pwd = pwd;
		this.name = name;
		this.address = address;
		this.email = email;
		this.phone = phone;
		this.join_date = join_date;
		this.point = point;
		this.admin = admin;
	}
	
	@Override
	public String toString() {
		return "Member [id=" + id + ", pwd=" + pwd + ", name=" + name + ", address=" + address + ", email=" + email
				+ ", phone=" + phone + ", join_date=" + join_date + ", point=" + point + ", admin=" + admin + "]";
	}

	public String getId() {
		return id;
	}

	public String getPwd() {
		return pwd;
	}

	public String getName() {
		return name;
	}

	public String getAddress() {
		return address;
	}

	public String getEmail() {
		return email;
	}

	public String getPhone() {
		return phone;
	}

	public Date getJoin_date() {
		return join_date;
	}

	public int getPoint() {
		return point;
	}

	public String getAdmin() {
		return admin;
	}

	public void setId(String id) {
		this.id = id;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public void setJoin_date(Date join_date) {
		this.join_date = join_date;
	}

	public void setPoint(int point) {
		this.point = point;
	}

	public void setAdmin(String admin) {
		this.admin = admin;
	}
	
	
}
