package shop.model.vo;

import java.sql.Date;

public class Review {

	private int reviewNo;
	private String id;
	private int proNo;
	private int proStar;
	private int orderNo;
	private String proReview;
	private java.sql.Date reviewDate;

	public Review() {

	}

	public Review(int reviewNo, String id, int proNo, int proStar, int orderNo, String proReview, Date reviewDate) {
		this.reviewNo = reviewNo;
		this.id = id;
		this.proNo = proNo;
		this.proStar = proStar;
		this.orderNo = orderNo;
		this.proReview = proReview;
		this.reviewDate = reviewDate;
	}

	public int getReviewNo() {
		return reviewNo;
	}

	public void setReviewNo(int reviewNo) {
		this.reviewNo = reviewNo;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public int getProNo() {
		return proNo;
	}

	public void setProNo(int proNo) {
		this.proNo = proNo;
	}

	public int getProStar() {
		return proStar;
	}

	public void setProStar(int proStar) {
		this.proStar = proStar;
	}

	public int getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(int orderNo) {
		this.orderNo = orderNo;
	}

	public String getProReview() {
		return proReview;
	}

	public void setProReview(String proReview) {
		this.proReview = proReview;
	}

	public java.sql.Date getReviewDate() {
		return reviewDate;
	}

	public void setReviewDate(java.sql.Date reviewDate) {
		this.reviewDate = reviewDate;
	}

	@Override
	public String toString() {
		return "Review [reviewNo=" + reviewNo + ", id=" + id + ", proNo=" + proNo + ", proStar=" + proStar
				+ ", orderNo=" + orderNo + ", proReview=" + proReview + ", reviewDate=" + reviewDate + "]";
	}

}
