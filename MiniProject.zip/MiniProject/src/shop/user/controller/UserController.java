package shop.user.controller;


import java.util.List;

import shop.model.service.MemberService;
import shop.model.vo.Cart;
import shop.model.vo.Member;
import shop.model.vo.Product;
import shop.model.dao.CartDao;
import shop.model.dao.ProductDao;

public class UserController {
	
	private CartDao cartDao = new CartDao();
	ProductDao productDao = new ProductDao();
	Product product = new Product();	
	private MemberService memberService = new MemberService();
	
	//회원가입
	public int insertMember(Member member) {
		return memberService.insertMember(member);
	}
	//로그인
	public int loginMember(Member member) {
		return memberService.loginMember(member);
	}
	
	//상품
	public List<Product> productInquiry() { // 상품명, 상품 가격, 재고, 판매여부
		return productDao.selectAll();
	}
	public List<String> selectCategory() {
		return productDao.category();
	}
	public List<Product> selectCategoryPro(String categoryName) {
		return productDao.selectCategoryPro(categoryName);
	}
	public Product selectProduct(int selectProNo) {
		return productDao.selectOne(selectProNo);
	}
	
	//장바구니
	public Cart selectOne(String loginId, int proNo) {
		return cartDao.selectOne(loginId, proNo);
	}
	public List<Cart> selectCart(String loginId) {
		return cartDao.selectAll(loginId);
	}
	public int addCart(int proNo, String loginId, int cartCnt) {
		return cartDao.insertCart(proNo, loginId, cartCnt);
	}
	public int deleteCartOne(String loginId, int proNo) {
		
		return cartDao.deleteProduct(loginId, proNo);
	}
	public int deleteCartAll(String loginId) {
		return cartDao.deleteAll(loginId);
	}
	public int updateCart(int proNo,String loginId, int addCnt) {
		return cartDao.updateAddCnt(proNo, loginId, addCnt);
	}
}
